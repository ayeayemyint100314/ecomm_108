<?php
if(!isset($_SESSION))
{
    session_start();
}

if( $_SERVER['REQUEST_METHOD']=="GET" && isset($_GET['itemID']))
{       $itemID = $_GET['itemID'];
       // echo "$itemID is clicked";
       if(array_key_exists('cart', $_SESSION))
       {
            $cart = $_SESSION['cart']; // getting current cart from session
            if(!array_key_exists($itemID, $cart)) // newly clicked item
            {   
                $cart[$itemID] = 1;
            }
       }
       else 
       {// if not cart key exists
            $cart = array();
            $cart[$itemID] = 1; // itemid 3 is clicked, its quantity value will be 1        

       }

       $_SESSION['cart'] = $cart;
      // print_r(  $cart);
      header("Location:customerViewItem.php");

}





?>